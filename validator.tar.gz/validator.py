# ---------------------------------------------------
#    Name: Purnapushkala Hariharan
#    ID: 1623714
#    CMPUT 274, Fall  2020
#
#    Weekly Exercise  1: Password Validator and Generator
# ---------------------------------------------------

length_password = 8
# length_password is global variable.


def validate(password):
    """ Analyzes an input password to determine if it is "Secure", "Insecure",
    or "Invalid" based on the assignment description criteria.

    Arguments:
        password (string): a string of characters

    Returns:
        result (string): either "Secure", "Insecure", or "Invalid".
    """
    spc_char = list("!-$%&'()*+,./:;<=>?_[]^`{|}~")
    # This assignment lists all the special charecters.
    isupper = str.isupper
    islower = str.islower
    isnumeric = str.isnumeric
    # In the above three assignments, the "is" functions are extracted as they
    # are methods of str type and are given a new name.
    upper = 0
    lower = 0
    digit = 0
    special = 0
    output = " "

    if " " in password or "@" in password or "#" in password or \
       len(password) < length_password:
        output = "Invalid"
    elif len(password) >= length_password:
        for charec in range(len(password)):
            """ The for loop runs from 0 to length of password - 1 and check
            and count if each of charecter in the password is an upper case,
            lower case digit or a special charecter (as defined above).
            """
            if isupper(password[charec]):
                upper = upper + 1
            elif islower(password[charec]):
                lower = lower + 1
            elif password[charec] in spc_char:
                special = special + 1
            elif isnumeric(password[charec]):
                digit = digit + 1
        if (upper > 0 and lower > 0 and digit > 0 and special > 0):
            # If the password contains atleast one uppercase, lowercase, digit
            # and special character, when the length is greater than 8 then
            # the password is secure.
            output = "Secure"
        else:
            output = "Insecure"
    return(output)
    pass


def generate(n):
    """ Generates a password of length n which is guaranteed to be
    Secure according to the given criteria.

    Arguments:
        n (integer): the length of the password to generate, n >= 8.

    Returns:
        secure_password (string): a Secure password of length n.
    """
    alpha_lower = list([])
    alpha_upper = list([])
    secure_password = list([])
    alpha = list([])
    for charec in range(97, 123):
        alpha_lower.append(chr(charec))
    # The above 2 statements generates a list of lowercase a - z.
    for charec in range(65, 91):
        alpha_upper.append(chr(charec))
    # The above 2 statements generates a list of uppercase A - Z.
    spc_char = list("!-$%&'()*+,./:;<=>?_[]^`{|}~")
    # This assignment lists all the special charecters.

    import random
    secure_password = random.choice(alpha_lower) + random.choice(alpha_upper) \
        + str(random.randint(0, 10)) + random.choice(spc_char)
    # The above statement picks a random lowerletter, upperletter, single
    # digit and a special character and forms a string.
    alpha = alpha_lower + alpha_upper + list("0123456789") + spc_char
    # The above assignment creates a list containing all the lower case,
    # upper case, numbbers from 0-9 and special charecters.
    for i in range(n-4):
        secure_password = secure_password + random.choice(alpha)
    # The above loop runs from 0 to length of password - 5 as we have already
    # found 4 charecters for the password. The loop further adds a random
    # alphanumeric/special charecter to the 4 charecter password till it
    # reaches the required length.
    secure_password = list(secure_password)
    random.shuffle(secure_password)
    # The charecters in the created password are further shuffled for further
    # security.
    return(''.join(secure_password))
    # The charecters in the password is joined to form a string and returned.
    pass


if __name__ == "__main__":
    # Any code indented under this line will only be run
    # when the program is called directly from the terminal
    # using "python3 validator.py". This can be useful for
    # testing your implementations.

    check = input("Enter a password")
    print(validate(check))
    n = int(input("Enter the password length"))
    if n < length_password:
        print("Invalid number, number must be greater than or equal to 8")
    else:
        print(generate(n))
    pass
