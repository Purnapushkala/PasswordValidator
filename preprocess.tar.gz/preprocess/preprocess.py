# --------------------------------------------
#    Name: Purnapushkala Hariharan
#    ID: 1623714
#    CMPUT 274, Fall  2020
#
#    Weekly Exercise #4: Text Preprocessor
# --------------------------------------------

import sys
stopwords = ["i", "me", "my", "myself", "we", "our", "ours", "ourselves",
             "you", "your", "yours", "yourself", "yourselves", "he", "him",
             "his", "himself", "she", "her", "hers", "herself", "it", "its",
             "itself", "they", "them", "their", "theirs", "themselves", "what",
             "which", "who", "whom", "this", "that", "these", "those", "am",
             "is", "are", "was", "were", "be", "been", "being", "have", "has",
             "had", "having", "do", "does", "did", "doing", "a", "an", "the",
             "and", "but", "if", "or", "because", "as", "until", "while", "of",
             "at", "by", "for", "with", "about", "against", "between",
             "into", "through", "during", "before", "after", "above", "below",
             "to", "from", "up", "down", "in", "out", "on", "off", "over",
             "under", "again", "further", "then", "once", "here", "there",
             "when", "where", "why", "how", "all", "any", "both", "each",
             "few", "more", "most", "other", "some", "such", "no", "nor",
             "not", "only", "own", "same", "so", "than", "too", "very", "s",
             "t", "can", "will", "just", "don", "should", "now"]


def demo_command_line():
    """ Getting the mode from command line and checks if neccesary
    number of arguments are passed. If not, an error message is passed.
    Arguments:
        None
    Returns:
        mode (string): mode for preprocessing is entered in the command line.
    """
    if len(sys.argv) > 2:
        print("Too many command line arguments")
        print("Currect Usage: python3 preprocess.py mode")
        print("where mode is keep-symbols, keep-digits or keep-stops")
        quit()
    elif len(sys.argv) < 1:
        print("Too few command line arguments")
        print("Currect Usage: python3 preprocess.py mode")
        print("where mode is keep-symbols, keep-digits or keep-stops")
        quit()
    elif len(sys.argv) == 2:
        # so the mode is the second argument
        mode = sys.argv[1]
        if mode != "keep-symbols" and mode != "keep-digits" and \
           mode != "keep-stops":
            print("Invalid Mode")
            print("Currect Usage: python3 preprocess.py mode")
            print("where mode is keep-symbols, keep-digits or keep-stops")
            quit()
        else:
            return(mode)
    else:
        mode = "normal"
    pass


def symbols(str_list):
    """ Processing input line by stripping numbers form alphanumeric words,
    removing stopwords, retaining symbols to give a processed text.
    Arguments:
        str_list (list): Input line in lowercase as a list of space separated
        words.
    Returns:
        result (list): Final processed text as a list od space separated words
        containing symbols.
    """
    result = []
    for i in str_list:
        if not str.isnumeric(i) and i not in stopwords:
            # If a word in str_list is not completely numeric, then the 
            # digits are stripped from the word.
            i = i.strip("0,1,2,3,4,5,6,7,8,9")
            result.append(i)
        elif i in stopwords:
            pass
        else:
            result.append(i)
    return(result)
    pass


def preprocess():
    """ Processing input line by converting input line to lowercase,removing
    symbols, stripping numbers form alphanumeric words, removing stopwords,
    and printing the processed text. Depending on the mode, some of the 
    preprocessing are omitted.
    Arguments:
        None
    Returns:
        None
    """
    mode = demo_command_line()

    string = input()
    alphnum = ""
    string = string.lower()
    for i in string:
        if (str.isalnum(i) or i == " ") and mode != "keep-symbols":
            # Each charecter in the loop is checked and retained only
            # if it is a alphabet of number when the mode is not keep-symbols.
            alphnum = alphnum + i
        elif mode == "keep-symbols":
            alphnum = alphnum + i
    str_list = alphnum.split(" ")
    result = []
    if mode == "keep-symbols":
        result = symbols(str_list)
    else:
        for i in str_list:
            if not str.isnumeric(i) and mode != "keep-digits":
                i = i.strip("0,1,2,3,4,5,6,7,8,9")
            if (mode != "keep-digits") and (not str.isnumeric(i)) and \
               (not str.isalpha(i)):
                pass
            elif mode != "keep-stops" and i in stopwords:
                pass
            else:
                result.append(i)
    print(*result)
    pass


if __name__ == "__main__":
    # Any code indented under this line will only be run
    # when the program is called directly from the terminal
    # using "python3 preprocess.py". This is directly relevant
    # to this exercise, so you should call your code from here.
    preprocess()
    pass
