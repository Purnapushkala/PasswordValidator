"""
Name: Purnapushkala Hariharan
Student ID: 1623714
CMPUT 274, Fall  2020
Weekly Exercise  7: Dr. Moneybags
"""


def moneyclub(money, n):
    """
    Finds and returns the largest number N such that there are atleat N
    applicants with N million dollars.
    Arguments:
        A list money and the length of the list n.
    Returns:
        the threshold integer n
    """
    money.sort()
    for i in range(n-1, -1, -1):
        if money[0] >= n:
            # If the minimum of the list is greater than number of applicants,
            # the length of the list is threshold.
            return(n)
        elif n-i-1 >= money[i]:
            return(n-i-1)


if __name__ == "__main__":
    n = int(input())
    money = [0] * n
    # I initializes an list containing 0 on length n
    for i in range(n):
        money[i] = int(input())
    if n == 0:
        # If there are no applicants, the threshold is 0.
        print("0")
    elif n < 0:
        print("The number of applicats can't be negative")
    else:
        print(moneyclub(money, n))
