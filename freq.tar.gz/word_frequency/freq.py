# ---------------------------------------------------
#    Name: Purnapushkala Hariharan
#    ID: 1623714
#    CMPUT 274, Fall  2020
#
#    Weekly Exercise  3: Word Frequency
# ---------------------------------------------------

import sys


def demo_command_line():
    """ Getting the arguments from command line and checks if neccesary
    number of arguments are passed. If not, an error message is passed.
    Arguments:
        None
    Returns:
        filename (string): Name of the file entered in the command line.
    """

    print(sys.argv[0])
    # the first argument is the program name
    if len(sys.argv) > 2:
        print("Too many command line arguments")
        print("Correct Usage: python3 freq.py filename")
        print("where filename is the name of the input file")
        quit()
    elif len(sys.argv) < 2:
        print("Too few command line arguments")
        print("Correct Usage: python3 freq.py filename")
        print("where filename is the name of the input file")
        quit()
    else:
        # the filename is the second argument
        filename = sys.argv[1]
        return(filename)
    pass


def readfile():
    """ Reads the file contents word by word and saves each word in
    a list.
    Arguments:
        None
    Returns:
        word_list(list) : A list containing all the words in the file.
        filename (string): The name of the input file.
    """
    filename = demo_command_line()
    word_list = []
    file = open(filename, 'r')

    for line in file:
        for word in line.split():
            # The loop extracts each word from each line
            word_list.append(word)
    file.close()
    return(word_list, filename)


def freq():
    """ Counts the occurance of each word in the file, sorts it, finds the
    relative frequency and writes them on a new output file.
    Arguments:
        None
    Returns:
        None
    """
    word_list, filename = readfile()
    dict_word = {}
    for i in word_list:
        if i not in dict_word:
            dict_word[i] = 0
            # When a word is saved first time in the dictionary, dict_word,
            # it gets a value of 0.
        else:
            dict_word[i] += 1
            # Subsequent occurances of a word increases it's key value by 1.
    for i in dict_word:
        dict_word[i] = dict_word[i]+1
    file = open(filename + ".out", "w")
    for i in sorted(dict_word):
        # The loop runs through the sorted dictionary.
        file.write(i)
        file.write(" ")
        file.write(str(dict_word[i]))
        # The count as string in written in the file.
        file.write(" ")
        file.write(str(round(dict_word[i]/len(word_list), 3)))
        # The realtive frequency is calculated to 3 decimal places, converted
        # to a string and then wriiten to the file.
        file.write("\n")
    file.close()
    pass


if __name__ == "__main__":
    # Any code indented under this line will only be run
    # when the program is called directly from the terminal
    # using "python3 freq.py". This is directly relevant to
    # this exercise, so you should call your code from here.
    freq()
    pass
